const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Student = require('../models/student.model'); // Ensure the correct path to your model

router.get('/', (req, res) => {
    res.render('student/addOrEdit', {
        viewTitle: 'Insert Student'
    });
});

router.post('/', (req, res) => {
    if (req.body._id == "") {
        insertRecord(req, res);
    } else {
        updateRecord(req, res);
    }
});

function insertRecord(req, res) {
    var student = new Student();
    student.fullName = req.body.fullName;
    student.email = req.body.email;
    student.mobile = req.body.mobile;
    student.city = req.body.city;

    student.save()
        .then(doc => {
            res.redirect('student/list');
        })
        .catch(err => {
            console.log('Error during insert:', err);
            res.status(500).send('Internal Server Error');
        });

}

function updateRecord(req, res) {
    Student.findOneAndUpdate(
        { _id: req.body._id }, // Correct the spelling from req.bdy._id to req.body._id
        req.body,
        { new: true },
        (err, doc) => {
            if (!err) {
                res.redirect('student/list');
            } else {
                console.log("Error during update: " + err);
            }
        }
    );
}

router.get('/list', async (req, res) => {
    try {
        const students = await Student.find();
        res.render('student/list', { list: students });
    } catch (error) {
        console.error('Error fetching students:', error);
        res.status(500).send('Internal Server Error');
    }
});

router.get("/:id", (req, res) => {
    Student.findById(req.params.id, (err, doc) => {
        if (!err) {
            res.render('student/addOrEdit', {
                viewTitle: "Update Student",
                student: doc,
            });
            console.log(doc);
        }
    });
});

router.get('delete/:id', (req, res) => { // Add slash at the beginning of the path
    Student.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) {
            res.redirect('student/list');
        } else {
            console.log("Error in deletion: " + err);
        }
    });
});

module.exports = router;
